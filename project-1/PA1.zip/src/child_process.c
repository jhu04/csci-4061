#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include "hash.h"

#define PATH_MAX 1024
#define ERR_MESS 2048

int main(int argc, char* argv[]) {
    if (argc != 5) {
        printf("Usage: ./child_process <blocks_folder> <hashes_folder> <N> <child_id>\n");
        return 1;
    }

    // TODO : Ask TA -> if we need to make buffer of 5(in child_id) and 2*SHA_BLOCK_SIZE+1 seperate constants
    char* blocks_folder = argv[1];
    char* hashes_folder = argv[2];
    char* N_string = argv[3];
    int N = atoi(N_string); // Number of blocks
    int cur_id = atoi(argv[4]);
    
    // If the current process is a leaf process, read in the associated block file 
    // and compute the hash of the block.

    if(cur_id >= N-1 && cur_id <= 2*N-2){
        // Open file to read leaf data from
        char block_name[PATH_MAX];
        sprintf(block_name, "%s/%d.txt", blocks_folder, cur_id-N+1);

        // Compute hash and store it in a buffer
        char hash_buf[2*SHA256_BLOCK_SIZE+1];
        hash_data_block(hash_buf, block_name);

        // Open file to write hash into
        char hash_name[PATH_MAX];
        sprintf(hash_name, "%s/%d.out", hashes_folder, cur_id);

        // Write computed hash into the file
        // Error check on fopen to exit gracefully
        FILE* fp = fopen(hash_name, "w");
        if(fp == NULL){
            char err_message[ERR_MESS];
            sprintf(err_message, "Failed to open file: %s", hash_name);
            perror(err_message);
        }
        
        // Error check on fwrite to exit gracefully
        while(fwrite(hash_buf, sizeof(char), 2*SHA256_BLOCK_SIZE+1, fp) != 2*SHA256_BLOCK_SIZE+1){
            // TODO : do we need to delete this? originally while was if, but pseudocode said forceful write
            // char write_err_message[ERR_MESS];
            // sprintf(write_err_message, "Failed to write has to file: %s", hash_name);
            // perror(write_err_message);
        }     
    }
    // If the current process is not a leaf process, spawn two child processes using  
    // exec() and ./child_process. 
    else{
        pid_t pid;
        for(int i=0; i<2; i++){
            pid = fork();
            // TODO: Ask TA if we have to restart fork on error
            // while( (pid=fork()) == -1);
            if(pid == -1){
                perror("Failed to fork a child process");
                exit(-1);
            }else if(pid == 0){
                char child_id[5];
                sprintf(child_id, "%d", 2*cur_id+i+1);
                
                execl("child_process", "./child_process", blocks_folder, hashes_folder, N_string, child_id, NULL);
                char exec_err_message[ERR_MESS];
                sprintf(exec_err_message, "Failed to execl child process, i.e., failed to spawn tree node child");
                perror(exec_err_message);
                exit(-1);
            } else {
                // TODO: Ask TA if we need to error check wait
                if(wait(NULL) == -1){
                    perror("Parent process fails to wait for child process. If this happens, fatal erorr occured");
                    exit(-1);
                }
            }
        }

        // Retrieve the two hashes from the two child processes from output/hashes/
        // and compute and output the hash of the concatenation of the two hashes.
        char child1_name[PATH_MAX];
        sprintf(child1_name, "%s/%d.out", hashes_folder, 2*cur_id+1);

        // Open left childs hash file with error check
        FILE* child1_fp = fopen(child1_name, "r");
        if(child1_fp == NULL){
            char failed_to_open_child1[ERR_MESS];
            sprintf(failed_to_open_child1, "Failed to open %s", child1_name);
            perror(failed_to_open_child1);
        }

        char hash1[2*SHA256_BLOCK_SIZE+1];
        // Ensures fread reads all bytes from the hash
        while(fread(hash1, sizeof(char), 2*SHA256_BLOCK_SIZE+1, child1_fp)!=2*SHA256_BLOCK_SIZE+1);

        // Ensures fclose closes the file
        while(fclose(child1_fp)==-1);

        char child2_name[PATH_MAX];
        sprintf(child2_name, "%s/%d.out", hashes_folder, 2*cur_id+2);

        // Open right childs hash file with error check
        FILE* child2_fp = fopen(child2_name, "r");
        if(child2_fp == NULL){
            char failed_to_open_child2[ERR_MESS];
            sprintf(failed_to_open_child2, "Failed to open %s", child2_name);
            perror(failed_to_open_child2);
        }

        char hash2[2*SHA256_BLOCK_SIZE+1];
        // Ensures fread reads all bytes from the hash
        while(fread(hash2, sizeof(char), 2*SHA256_BLOCK_SIZE+1, child2_fp)!=2*SHA256_BLOCK_SIZE+1);

        // Ensures fclose closes the file
        while(fclose(child2_fp)==-1);

        char parent_hash[2*SHA256_BLOCK_SIZE+1];
        compute_dual_hash(parent_hash, hash1, hash2);

        char parent_name[PATH_MAX];
        sprintf(parent_name, "%s/%d.out", hashes_folder, cur_id);

        // Open parent node hash file with error check
        FILE *parent_p = fopen(parent_name, "w");
        if(parent_p == NULL){
            char failed_to_open_parent[ERR_MESS];
            sprintf(failed_to_open_parent, "Failed to open %s", parent_name);
            perror(failed_to_open_parent);
        }

        // Ensures fwrite into parent hash file with error check
        while(fwrite(parent_hash, sizeof(char), 2*SHA256_BLOCK_SIZE+1, parent_p) != 2*SHA256_BLOCK_SIZE+1){
            // TODO : do we need to delete this? originally while was if, but pseudocode said forceful write
            // char write2_err_message[ERR_MESS];
            // sprintf(write2_err_message, "Failed to write has to file: %s", parent_hash);
            // perror(write2_err_message);
        }   
        // Ensures fclose closes the file
        while(fclose(parent_p)==-1);
    }
}

