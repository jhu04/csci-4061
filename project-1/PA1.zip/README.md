Project group number: 13

Group member names and x500s:
- Jeffrey Hu (hu000557)
- Devajya Khanna (khann077)
- Sameen Rahman (rahma262)

The name of the CSELabs computer that you tested your code on: csel-kh1260-03.cselabs.umn.edu

Any changes you made to the Makefile or existing files that would affect grading: N/A

Any assumptions : N/A

Plan outlining individual contributions for each member of your group:
We plan to meet on Zoom and have one person share their screen while the 
others assist by reviewing, looking up information in the writeup/documentation, etc.

Every 30 minutes, we will switch the screen sharer/typer.

Generally, the above process will result in the following assignments.
- README: Jeffrey Hu, Sameen Rahman
- 3.1 Partitioning Input Data into N files: Jeffrey Hu, Devajya Khanna, Sameen Rahman
- 3.2 Creating Merkle Process Tree and Hashing Files: Switch every 30 minutes
    - 3.2.1 Leaf Process: Switch every 30 minutes
    - 3.2.2 Non-Leaf Process: Switch every 30 minutes
- merkle.c: Switch every 30 minutes
- Error Handling: Switch every 30 minutes
- Code Review: Jeffrey Hu, Devajya Khanna, Sameen Rahman

Plan on how you are going to implement the process tree component of creating the Merkle tree (high-level pseudocode would be acceptable/preferred for this part):
```

Pseudocode change log :  
    0. Original pseudocode stated opening the block file. Our code does not need to do this, and instead only requires a block_file name.

    1. Original pseudocode stated reading from a block file explicitly. Our code does not need to do this, and instead uses the data in the block to compute the hash using hash_data_block.

    2. Original pseudocode waits for two child processes outside the fork spawning for loop (do twice). Our code waits inside.

    3. Original pseudocode stated closing files if wait failed when spawning child processes. Our code doesn't need to do this, since no files are open.

    4. Original pseudocode does not document how to generate parent hash. Further elaboration is added here.

    5. Original pseudocode only enforced forceful write on the parent nodes. Our codes enforces it on both parent and leaf nodes while writing hashes.

main:
    if process is leaf:
        open corresponding block file using cur_id
        
        compute hash_data_block
        store in hash_buf

        open/create corresponding hash file
        if open/create  fails:
            close all files
            terminate gracefully

        write hash to corresponding hash file 
        if write fails:(forceful write)
            retry write

        close all files
        exit
    else:
        do twice : 
            pid = fork()
            if pid is child:
                exec ./child_process
                exit(-1)
        
            wait for both child processes to terminate

            if wait fails:
                exit gracefully
        
        Obtain left and right child hashes 
            - for both left and right : open file, grab hash, put in local buffer, error check the read and open
            

        generate parent hash
            - compute_dual_hash(left_hash, right_hash)

        
        open parent hash file
        if open fails:
            close all files
            exit(-1)
        
        write parent hash to parent hash file 
        if write fails:(force full write)
            retry write
        
        close all files
        exit
```